import React from 'react';
import OverHeadBar from "./OverHeadBar";

function TourPage() {
    return (
        <div>
            <OverHeadBar currentPage='TOUR'/>
        </div>
    );
}

export default TourPage;