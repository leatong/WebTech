import React from 'react';
import home from './HomePage.module.css'

function Tshirt1Page() {
    return(
        <div className={home.center}>
            to be built
        </div>
    )
}

export default Tshirt1Page;